const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/createuser', async (req, res) => {
    try {
        await User.create({
            name: "Achira Shashik",
            password: "123456",
            email: "achirashashik1@gmail.com",
            location: "Sri Lanka",
        });
        res.json({ success: true });
    } catch (error) {
        console.error(error);
        res.json({ success: false });
    }
});

module.exports = router;
