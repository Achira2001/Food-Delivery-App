const mongoose = require('mongoose');
require('dotenv').config();

const mongoURI = process.env.MONGO_URI;

const mongoDB = async () => {
    try {
        await mongoose.connect(mongoURI);
        console.log("Connected to MongoDB");

        // Optional: Fetch some data to verify connection
        const fetchedData = await mongoose.connection.db.collection("food_items").find({}).toArray();
        console.log(fetchedData);
    } catch (error) {
        console.error("Error connecting to MongoDB", error.message);
        process.exit(1); // Exit the process with a failure
    }
};

module.exports = mongoDB;
